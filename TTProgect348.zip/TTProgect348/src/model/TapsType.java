package model;

public class TapsType {

	public int getTTno() {
		return TTno;
	}
	public void setTTno(int tTno) {
		TTno = tTno;
	}
	public String getTTTypename() {
		return TTTypename;
	}
	public void setTTTypename(String tTTypename) {
		TTTypename = tTTypename;
	}
	private int TTno;
	private String TTTypename;

}
