package model;

public class LetTaps {
	public int getLno() {
		return Lno;
	}
	public void setLno(int lno) {
		Lno = lno;
	}
	public String getLTaps() {
		return LTaps;
	}
	public void setLTaps(String lTaps) {
		LTaps = lTaps;
	}
	public String getLTTypename() {
		return LTTypename;
	}
	public void setLTTypename(String lTTypename) {
		LTTypename = lTTypename;
	}
	public String getLTime() {
		return LTime;
	}
	public void setLTime(String lTime) {
		LTime = lTime;
	}
	private int Lno;
	private String LTaps;
	private String LTTypename;
	private String LTime;
	private String Lname;
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}

}
