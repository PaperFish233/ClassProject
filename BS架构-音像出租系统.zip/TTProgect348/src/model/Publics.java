package model;

public class Publics {


	public int getPno() {
		return Pno;
	}
	public void setPno(int pno) {
		Pno = pno;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public String getPcontent() {
		return Pcontent;
	}
	public void setPcontent(String pcontent) {
		Pcontent = pcontent;
	}
	private int Pno;
	private String Pname;
	private String Pcontent;
	public String getPtime() {
		return Ptime;
	}
	public void setPtime(String ptime) {
		Ptime = ptime;
	}
	private String Ptime;

}
