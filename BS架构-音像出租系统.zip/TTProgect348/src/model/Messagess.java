package model;

public class Messagess {
	
	public int getMno() {
		return Mno;
	}
	public void setMno(int mno) {
		Mno = mno;
	}
	public String getMcontent() {
		return Mcontent;
	}
	public void setMcontent(String mcontent) {
		Mcontent = mcontent;
	}
	private int Mno;
	private String Mcontent;

	
	public String getMtime() {
		return Mtime;
	}
	public void setMtime(String mtime) {
		Mtime = mtime;
	}
	private String Mtime;

}
