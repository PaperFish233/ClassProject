package model;

public class Taps {


	public int getTno() {
		return Tno;
	}
	public void setTno(int tno) {
		Tno = tno;
	}
	public String getTname() {
		return Tname;
	}
	public void setTname(String tname) {
		Tname = tname;
	}
	public String getTTTypename() {
		return TTTypename;
	}
	public void setTTTypename(String tTTypename) {
		TTTypename = tTTypename;
	}
	private int Tno;
	private String Tname;
	public int getTTypeno() {
		return TTypeno;
	}
	public void setTTypeno(int tTypeno) {
		TTypeno = tTypeno;
	}
	private int TTypeno;
	private String TTTypename;
	public String getTTTo() {
		return TTTo;
	}
	public void setTTTo(String tTTo) {
		TTTo = tTTo;
	}
	private String TTTo;
	private String Tstate;
	public String getTstate() {
		return Tstate;
	}
	public void setTstate(String tstate) {
		Tstate = tstate;
	}
}
